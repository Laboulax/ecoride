
        <footer class="flux">
            <ul class="list-inline">
                <li class="list-inline-item"><a href="">A propos</a></li>
                <li class="list-inline-item"><a href="">Nous contacter</a></li>
                <li class="list-inline-item"><a href="">Conditions d'utilisation</a></li>
                <li class="list-inline-item"><a href="">Mentions légales</a></li>
            </ul>
        </footer>
    </body>

</html>