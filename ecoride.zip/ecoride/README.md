# Projet En Cours de Formation

Bonjour,


Dans index, penser à ajouter /studi-ecf-main devant les différents /index.php?* si déploiement en local



Vous pouvez lancer le projet via le lien https://studi-ecf-098592859cf4.herokuapp.com/?home
